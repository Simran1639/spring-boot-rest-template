package com.restTemplate.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRestTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRestTemplateApplication.class, args);
	}

}
